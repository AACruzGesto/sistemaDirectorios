package semiGroup;

interface IOperation {
 Integer operate(Integer a , Integer b );
}
