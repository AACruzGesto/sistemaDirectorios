package semiGroup;

public class AddModulo implements IOperation{
    private Integer modulo;
    public AddModulo (Integer modulo){
        this.modulo = modulo;
    }
  
    @Override
    public Integer operate(Integer a, Integer b){
        return (a + b) % modulo;
    }

    public String toString(){
        return "AddModulo(" + modulo + ")";
    }   
}