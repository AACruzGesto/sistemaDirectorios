package semiGroup;

import java.util.Collection;

public class SemiGroup {
  private Collection<Integer> elementos;
  private IOperation operacion;

  public SemiGroup(IOperation operacion, Collection<Integer> elementos) {
    this.operacion = operacion;
    this.elementos = elementos;
  }

  public Integer calculate(Integer a, Integer b) {
    return operacion.operate(a, b);
  }

  public String toString() {
    return "Semigroup(" + operacion + ", " + elementos + ")";
  }
}