package semiGroup;

import java.sql.SQLNonTransientException;
import java.util.Arrays;

public class SemiGroupMain {
    public static void main(String[] args) {
        SemiGroup sg = new SemiGroup(new AddModulo(4), Arrays.asList(0, 1, 2, 3));
        System.out.println(sg.calculate(1, 2));
        System.out.println(sg.calculate(3, 4));
        System.out.println(sg);
    }
}
